/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //Q31: Write a program to take a number as input and print its equivalent binary representation.

/*
Sample Test Cases:
Input 1:
10
Output 1:
1010

Input 2:
7
Output 2:
111

*/

    int num;
    int binary[32]; // To store binary digits
    int i = 0;

    // Input number
    printf("Enter a number: ");
    scanf("%d", &num);

    // Edge case: if number is 0
    if (num == 0) {
        printf("0\n");
        return 0;
    }

    // Conversion process
    while (num > 0) {
        binary[i] = num % 2;  // Store remainder (0 or 1)
        num = num / 2;        // Divide by 2
        i++;
    }

    // Printing binary in reverse order
    for (int j = i - 1; j >= 0; j--) {
        printf("%d", binary[j]);
    }
    printf("\n");

    return 0;
}

