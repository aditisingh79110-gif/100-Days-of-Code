/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //Q3: Write a program to calculate the area and perimeter of a rectangle given its length and breadth.

/*
Sample Test Cases:
Input 1:
5 10
Output 1:
Area=50, Perimeter=30

Input 2:
3 7
Output 2:
Area=21, Perimeter=20

*/
     float Length, Width, Area, Perimeter;
    printf("Enter Length: ");
    scanf("%f", &Length);
    printf("Enter Width: ");
    scanf("%f", &Width);
    Area = Length*Width;
    Perimeter = 2*(Length+Width);
    printf("Area = %f\n", Area );
    printf("Perimeter = %f", Perimeter);
    

    return 0;
}
