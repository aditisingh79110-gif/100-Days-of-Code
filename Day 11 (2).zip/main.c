/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //Q22: Write a program to find profit or loss percentage given cost price and selling price.

/*
Sample Test Cases:
Input 1:
1000 1200
Output 1:
Profit 20%

Input 2:
1000 800
Output 2:
Loss 20%

Input 3:
1000 1000
Output 3:
No Profit No Loss

*/
float costprice, sellingprice, percentage;
printf("Enter costprice: ");
scanf("%f", &costprice);
printf("Enter sellingprice: ");
scanf("%f", &sellingprice);
if (costprice>sellingprice) {
    printf("Loss");
    percentage= ((costprice- sellingprice)/costprice)*100;
    printf("Loss percentage= %2f\n", percentage);
}
else if (sellingprice>costprice) {
    printf("Profit");
    percentage= ((sellingprice- costprice)/costprice)*100;
    printf("Profit percentage= %2f\n", percentage);
}
    return 0;
}
