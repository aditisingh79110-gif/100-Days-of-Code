/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Q64: Find the digit that occurs the most times in an integer number.

/*
Sample Test Cases:
Input 1:
112233
Output 1:
1

Input 2:
887799
Output 2:
7

*/
#include <stdio.h>

int main() {
    long long num;
    int count[10] = {0};
    int digit, i, maxDigit = 0;

    scanf("%lld", &num);

    // Count digits
    while(num > 0) {
        digit = num % 10;
        count[digit]++;
        num /= 10;
    }

    // Find digit with max frequency
    for(i = 0; i < 10; i++) {
        if(count[i] > count[maxDigit]) {
            maxDigit = i;
        }
    }

    printf("%d", maxDigit);

    return 0;
}
