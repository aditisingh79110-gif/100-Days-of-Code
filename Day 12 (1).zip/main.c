/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //Q23: Write a program to calculate library fine based on late days as follows: 
//First 5 days late: ₹2/day 
//Next 5 days late: ₹4/day 
//Next 20 days days late: ₹6/day 
//More than 30 days: Membership Cancelled.

/*
Sample Test Cases:
Input 1:
4
Output 1:
Fine ₹8

Input 2:
8
Output 2:
Fine ₹32

Input 3:
15
Output 3:
Fine ₹90

Input 4:
31
Output 4:
Membership Cancelled

*/
int days,fine;
printf("Enter the days late: ");
scanf("%d", &days);
if (days<= 5) {
    fine = days * 2;
    printf("fine= Rs.%d\n", fine);
}
else if (days<= 10) {
    fine = days*4;
    printf("fine = Rs. %d\n", fine);
}
else if (days<=.30) {
    fine= days*6;
    printf("fine = Rs. %d\n", fine);
}
else if (days>30) {
    printf("Membership Cancelled");
}
    return 0;
}
