/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Q39: Write a program to find the product of odd digits of a number.

/*
Sample Test Cases:
Input 1:
12345
Output 1:
15 (1*3*5)

Input 2:
2468
Output 2:
1 (no odd digits, assume 1)

*/
#include <stdio.h>

int main() {
    int num, digit, product = 1;
    int hasOdd = 0;  // To track if there is any odd digit

    // Input number
    scanf("%d", &num);

    while (num > 0) {
        digit = num % 10;       // Extract last digit
        if (digit % 2 == 1) {   // Check if odd
            product *= digit;
            hasOdd = 1;         // Found at least one odd digit
        }
        num /= 10;
