/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //Q19: Write a program to classify a triangle as Equilateral, Isosceles, or Scalene based on its side lengths.

/*
Sample Test Cases:
Input 1:
3 3 3
Output 1:
Equilateral

Input 2:
3 3 4
Output 2:
Isosceles

Input 3:
2 3 4
Output 3:
Scalene

*/
int a, b, c;
printf("enter sied1: ");
scanf("%d", &a);
printf("enter sied2: ");
scanf("%d", &b);
printf("enter sied3: ");
scanf("%d", &c);
if (a==b && b==c) {
    printf("Triangle is Equilateral");
} else if (a==b|| b==c || c==a ) {
    printf("Triangle is Isosceles");
} else {
    printf("Triangle is Scalene");
}

    return 0;
}
