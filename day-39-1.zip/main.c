/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Q77: Check if the elements on the diagonal of a matrix are distinct.

/*
Sample Test Cases:
Input 1:
3 3
1 2 3
4 5 6
7 8 1
Output 1:
False

Input 2:
3 3
1 2 3
4 5 6
7 8 9
Output 2:
True

*/
#include <stdio.h>

int main() {
    int rows, cols, i, j, distinct = 1;
    scanf("%d %d", &rows, &cols);

    if(rows != cols) {
        printf("False");
        return 0;
    }

    int matrix[rows][cols];
    int diagonal[rows];

    // Read matrix and store diagonal elements
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
            if(i == j) {
                diagonal[i] = matrix[i][j];
            }
        }
    }

    // Check if diagonal elements are distinct
    for(i = 0; i < rows; i++) {
        for(j = i + 1; j < rows; j++) {
            if(diagonal[i] == diagonal[j]) {
                distinct = 0;
                break;
            }
        }
        if(!distinct) break;
    }

    if(distinct) {
        printf("True");
    } else {
        printf("False");
    }

    return 0;
}
