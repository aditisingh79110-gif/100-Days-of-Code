/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //Q14: Write a program to input a character and check whether it is a vowel or consonant using if–else.

/*
Sample Test Cases:
Input 1:
a
Output 1:
Vowel

Input 2:
b
Output 2:
Consonant

*/

char character;
printf("enter a character: ");
scanf("%c", &character);
if (character== 'a'|| character== 'A' ||
character=='e'|| character=='E'||
character=='i' || character=='I'||
character=='o' || character=='O'|| 
character=='u' || character=='U') {
 printf("character is vowel\n");
} else { printf("character is consonant\n");
}

    return 0;
}
