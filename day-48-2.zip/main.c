/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Q96: Reverse each word in a sentence without changing the word order.

/*
Sample Test Cases:
Input 1:
I love coding
Output 1:
I evol gnidoc

*/
#include <stdio.h>
#include <string.h>

void reverse(char* start, char* end) {
    while (start < end) {
        char temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }
}

int main() {
    char sentence[1000];
    scanf(" %[^\n]", sentence); // Reads the whole line

    int len = strlen(sentence);
    int i = 0, word_start = 0;

    while (i <= len) {
        if (sentence[i] == ' ' || sentence[i] == '\0') {
            reverse(sentence + word_start, sentence + i - 1);
            word_start = i + 1;
        }
        i++;
    }

    printf
