/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Q38: Write a program to find the sum of digits of a number.

/*
Sample Test Cases:
Input 1:
123
Output 1:
6

Input 2:
999
Output 2:
27

*/
#include <stdio.h>

int main() {
    int num, sum = 0, remainder;

    // Input number
    scanf("%d", &num);

    // Calculate sum of digits
    while (num > 0) {
        remainder = num % 10;   // Get last digit
        sum += remainder;       // Add to sum
        num = num / 10;         // Remove last digit
    }

    printf("%d\n", sum);

    return 0;
}
