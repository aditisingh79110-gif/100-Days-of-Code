/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Q94: Find the longest word in a sentence.

/*
Sample Test Cases:
Input 1:
I love programming
Output 1:
programming

*/
#include <stdio.h>
#include <string.h>

int main() {
    char sentence[1000];
    char longest[1000] = "";
    scanf(" %[^\n]", sentence); // Reads a whole line (including spaces)

    int maxLen = 0;
    char *word = strtok(sentence, " ");
    while (word != NULL) {
        int len = strlen(word);
        if (len > maxLen) {
            maxLen = len;
            strcpy(longest, word);
        }
        word = strtok(NULL, " ");
    }
    printf("%s\n", longest);
    return 0;
}
