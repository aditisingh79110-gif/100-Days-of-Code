/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   //Q2: Write a program to input two numbers and display their sum, difference, product, and quotient.

/*
Sample Test Cases:
Input 1:
10 2
Output 1:
Sum=12, Diff=8, Product=20, Quotient=5

Input 2:
7 3
Output 2:
Sum=10, Diff=4, Product=21, Quotient=2

*/
int num1, num2, sum, difference, product;
printf("enter num1: ");
scanf("%d", &num1);
printf("enter num2: ");
scanf("%d", &num2);
sum = num1+ num2;
printf("sum = %d\n", sum);
difference=num1-num2;
printf("difference= %d\n", difference);
product=num1*num2;
printf("product: %d\n", product);
float quotient;
if (num2 != 0){
    quotient = (float)num1 / num2;
    printf("quotient: %f\n", quotient);
} else{
    printf("Undefined! \n");
}

    return 0;
}