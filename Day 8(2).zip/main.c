/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   //Q16: Write a program to input three numbers and find the largest among them using if–else.

/*
Sample Test Cases:
Input 1:
3 7 5
Output 1:
Largest is 7

Input 2:
-1 -5 0
Output 2:
Largest is 0

*/
int num1, num2, num3;
printf("Enter num1: ");
scanf("%d", &num1);
printf("Enter num2: ");
scanf("%d", &num2);
printf("Enter num3: ");
scanf("%d", &num3);
if (num1>=num2 && num1>=num3) {
    printf("num1 is the largest one");
} else if (num2>=num1 && num2>=num3) {
    printf("num2 is the largest");
} else printf("num3 is the largest one");

    return 0;
}
