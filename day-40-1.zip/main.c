/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Q79: Perform diagonal traversal of a matrix.

/*
Sample Test Cases:
Input 1:
3 3
1 2 3
4 5 6
7 8 9
Output 1:
1 2 4 7 5 3 6 8 9

*/
#include <stdio.h>

int main() {
    int rows, cols, i, j;
    scanf("%d %d", &rows, &cols);

    int matrix[rows][cols];
    
    // Read matrix
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

    // Diagonal traversal
    for(int sum = 0; sum <= rows + cols - 2; sum++) {
        if(sum % 2 == 0) {
            // Even sum → traverse upward
            for(i = sum < rows ? sum : rows - 1, j = sum - i; i >= 0 && j < cols; i--, j++) {
                printf("%d ", matrix[i][j]);
            }
        } else {
            // Odd sum → traverse downward
            for(j = sum < cols ? sum : cols - 1, i = sum - j; j >= 0 && i < rows; j--, i++) {
                printf("%d ", matrix[i][j]);
            }
        }
    }

    return 0;
}
