/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   //Q18: Write a program to assign grades based on a percentage input.

/*
Sample Test Cases:
Input 1:
95
Output 1:
Grade A

Input 2:
82
Output 2:
Grade B

Input 3:
68
Output 3:
Grade D

Input 4:
50
Output 4:
Grade F

*/
int percentage;
printf("Enter your percentage: ");
scanf("%d", &percentage);
if (percentage >= 90) {
    printf(" GRADE: A\n");
} else if (percentage>=80 && percentage<90) {
    printf("GRADE: B\n");
} else if (percentage>=70 && percentage<80) {
    printf("GRADE: C\n");
} else if (percentage>=60 && percentage<70) {
    printf("GRADE: D\n");
} else if (percentage>=50 && percentage<60) {
    printf("GRADE: E\n");
} else if (percentage>=0&& percentage<50) {
    printf("GRADE: F\n");
}
    return 0;
}
